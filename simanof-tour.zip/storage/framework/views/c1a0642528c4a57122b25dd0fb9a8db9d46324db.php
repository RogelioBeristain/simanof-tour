

<?php $__env->startSection('content'); ?>
  <meta name="robots" content="noindex">
  <meta name="robots" content="nocache">
  <meta name="robots" content="noarchive">
<meta name="googlebot" content="noindex">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">

             <div class="text-title text-carbon text-center">

            <br>
                   
                        
                        <span class="text-orange">Lista de tutores</span> 
                      
                
           
                    </div>

           

                   

                    <list-tutors-component> </list-tutors-component>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rogel\Documento\Programming\laravel\simanof-tour\resources\views/user/tutors.blade.php ENDPATH**/ ?>