

<?php $__env->startSection('content'); ?>
  <meta name="robots" content="noindex">
  <meta name="robots" content="nocache">
  <meta name="robots" content="noarchive">
<meta name="googlebot" content="noindex">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

             <div class="text-title text-carbon text-regular text-center">

           <br>
                   
                        Hola  <span class="text-orange"><?php echo e($user->first_name); ?></span>  
                         
                    
                    
                    </div>
                     <div class=" text-regular-medinum text-carbon text-regular text-center">

           
                   
                       completa tu perfil o actúalizalo 
                    
                    
                    </div>
                     <div class=" text-regular-medinum text-carbon text-regular text-center">

          
                   para estar siempre en contacto contigo.
                        
                    
                    
                    </div>
                       
                      
                
           
                  

           


                    <profile-user-component> </profile-user-component>

    
            
        </div>
    </div>
</div>

   
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rogel\Documents\Programming\Proyectos\simanof-tour\resources\views/user/profile.blade.php ENDPATH**/ ?>