


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

             <div class="text-title text-carbon text-center">

            <br>
                  
                        
                       Descarga el PDF  <span class="text-orange">Tour Simanof</span> 
                       <br>
                      
                 <span> <a href="/audiciones/partituras/<?php echo e($title); ?>" target="_blank" rel="noopener noreferrer">Click aquí para descargar la partitura </a> 
                    </span>
           
                    </div>

           

                   

                     <div id="container-pdf">
      <object id="obj" type="application/pdf" data="/audiciones/partituras/<?php echo e($title); ?>" >

      <embed src="/audiciones/partituras/<?php echo e($title); ?>" type="application/pdf" />
      </object>
    </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rogel\Documento\Programming\laravel\simanof-tour\resources\views/audition/partitura.blade.php ENDPATH**/ ?>