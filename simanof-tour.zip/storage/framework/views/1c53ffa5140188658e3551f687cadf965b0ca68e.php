<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

             <div class="text-title text-carbon text-center">

            <br>
                   <!--  Hi <?php echo e(Auth::user()->first_name); ?>

            
                <br>  -->
                        
                        Welcome to   <span class="text-orange">Tour Simanof</span>  Account!
                      
                
           
                    </div>

           

                   

                    <dash-child-component></dash-child-component>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rogel\Documento\Programming\laravel\simanof-tour\resources\views/home.blade.php ENDPATH**/ ?>